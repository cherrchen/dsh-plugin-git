/**
 * Surface descriptor registry and lifecycle invocation. Descriptors carry
 * behavior metadata only; renderable contributions stay on the slot ledger.
 */
import type { DetailsSurfaceCloseReason, DetailsSurfaceDescriptor, DetailsSurfaceInstance } from './contract.ts';
/** Mutable registry of surface behavior descriptors. */
export declare class DetailsDescriptorRegistry {
    #private;
    /**
     * Register one descriptor. Duplicate ids throw.
     * @param descriptor - behavior metadata for a surface id.
     * @returns disposer that removes the descriptor.
     */
    register<P>(descriptor: DetailsSurfaceDescriptor<P>): () => void;
    /**
     * Look up a descriptor by surface id.
     * @param id - surface id.
     * @returns the descriptor, or undefined when absent (legacy consumers).
     */
    get(id: string): DetailsSurfaceDescriptor | undefined;
    /** Remove every descriptor (host unload). */
    clear(): void;
}
/**
 * Invoke a lifecycle callback; Host transitions continue after callback errors.
 * @param label - diagnostic label for the console error.
 * @param invoke - callback body.
 */
export declare function invokeLifecycle(label: string, invoke: () => void): void;
/**
 * Run open then activate for a newly committed instance.
 * @param registry - descriptor registry.
 * @param instance - committed instance.
 */
export declare function notifyOpened(registry: DetailsDescriptorRegistry, instance: DetailsSurfaceInstance): void;
/**
 * Run deactivate then close for a leaving instance.
 * @param registry - descriptor registry.
 * @param instance - instance being deactivated.
 * @param reason - close reason vocabulary entry.
 */
export declare function notifyClosed(registry: DetailsDescriptorRegistry, instance: DetailsSurfaceInstance, reason: DetailsSurfaceCloseReason): void;
//# sourceMappingURL=descriptor.d.ts.map