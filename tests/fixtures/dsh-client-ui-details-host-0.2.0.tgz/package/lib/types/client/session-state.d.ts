/**
 * Per-session details navigation state. Memory only; cleared on Host unload
 * or when a session disappears from the sessions list.
 */
import type { DetailsSurfaceInstance } from './contract.ts';
/** Maximum back-stack depth retained per session. */
export declare const DETAILS_HISTORY_LIMIT = 20;
/** One session's active surface and bounded back stack. */
export interface DetailsSessionState {
    active: DetailsSurfaceInstance | null;
    backStack: DetailsSurfaceInstance[];
}
/**
 * Create an empty session navigation record.
 * @returns idle session state.
 */
export declare function emptySessionState(): DetailsSessionState;
/** In-memory map of session id → details navigation state. */
export declare class DetailsSessionStore {
    #private;
    /**
     * Read session state without creating it.
     * @param sessionId - session key.
     * @returns the state, or undefined when never opened.
     */
    get(sessionId: string): DetailsSessionState | undefined;
    /**
     * Read or create session state.
     * @param sessionId - session key.
     * @returns mutable session state.
     */
    getOrCreate(sessionId: string): DetailsSessionState;
    /**
     * Drop one session's retained navigation.
     * @param sessionId - session key to purge.
     */
    delete(sessionId: string): void;
    /** Drop every session's retained navigation. */
    clear(): void;
    /**
     * @returns session ids currently retained in the store.
     */
    keys(): IterableIterator<string>;
}
//# sourceMappingURL=session-state.d.ts.map