/**
 * Typed errors thrown by `ctx.shellDetails` open-path validation and
 * takeover arbitration. Consumers should match with `instanceof`.
 */
/** No `shell.details.surface` contribution matches the requested surface id. */
export declare class DetailsSurfaceNotFoundError extends Error {
    readonly surfaceId: string;
    /**
     * @param surfaceId - requested surface id that was absent from the ledger.
     */
    constructor(surfaceId: string);
}
/**
 * More than one `shell.details.surface` contribution shares the same id.
 * Surface ids must be unique within the Host scope.
 */
export declare class DetailsSurfaceDuplicateError extends Error {
    readonly surfaceId: string;
    readonly matchCount: number;
    /**
     * @param surfaceId - duplicated surface id.
     * @param matchCount - number of matching contributions.
     */
    constructor(surfaceId: string, matchCount: number);
}
/**
 * DetailsHost registered into `details` but lost cell shadowing to another
 * occupant. Open state is rolled back before this error is thrown.
 */
export declare class DetailsTakeoverConflictError extends Error {
    readonly winnerId: string | undefined;
    /**
     * @param winnerId - id of the winning `details` occupant, when present.
     */
    constructor(winnerId?: string);
}
//# sourceMappingURL=errors.d.ts.map