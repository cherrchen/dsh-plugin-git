/**
 * ShellDetailsService (`ctx.shellDetails`): dynamic `details` takeover,
 * one active surface instance, descriptors, and layout open/close.
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import { type DetailsSurfaceDescriptor, type DetailsSurfaceInstance, type ShellDetailsController, type ShellDetailsFeature, type ShellDetailsOpenRequest, type ShellDetailsSnapshot } from './contract.ts';
/** `ctx.shellDetails` implementation. */
export declare class ShellDetailsService extends Service implements ShellDetailsController {
    static inject: string[];
    readonly apiVersion: 2;
    readonly features: ReadonlySet<ShellDetailsFeature>;
    private readonly owner;
    private readonly state;
    private readonly descriptors;
    private takeover;
    /**
     * @param ctx - owning plugin fiber. Takeover registrations ride this fiber
     * so consumer `open()` calls cannot pin the occupant to another plugin.
     */
    constructor(ctx: Context);
    /**
     * @returns the active surface id, or null while closed.
     */
    get activeId(): string | null;
    /**
     * @returns the active surface instance, or null while closed.
     */
    get activeInstance(): DetailsSurfaceInstance | null;
    /**
     * Read the public reactive snapshot.
     * @returns current shell details state.
     */
    getSnapshot(): ShellDetailsSnapshot;
    /**
     * Subscribe to public snapshot changes.
     * @param listener - notified after a distinct snapshot is published.
     * @returns unsubscribe.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Register optional behavior metadata for a surface id.
     * @param descriptor - lifecycle and future dedupe metadata.
     * @returns disposer that removes the descriptor.
     */
    registerSurface<P = unknown>(descriptor: DetailsSurfaceDescriptor<P>): () => void;
    /**
     * Occupy `details` with DetailsHost, activate a surface, and open the column.
     * @param id - registered `shell.details.surface` contribution id.
     */
    open(id: string): void;
    /**
     * Occupy `details` with DetailsHost, create an instance from `request`,
     * and open the column.
     * @param request - surface id plus optional payload.
     * @returns the committed active instance.
     */
    open<P = unknown>(request: ShellDetailsOpenRequest<P>): DetailsSurfaceInstance<P>;
    /**
     * Close the details column, clear the active instance, and dispose takeover.
     */
    close(): void;
    /**
     * Open `id` when it is not active; close when it is.
     * @param id - registered `shell.details.surface` contribution id.
     */
    toggle(id: string): void;
    /**
     * Whether any surface is active, or whether `id` is the active surface.
     * @param id - optional surface id to compare.
     * @returns open state for the requested query.
     */
    isOpen(id?: string): boolean;
    private closeWithReason;
    private registerTakeover;
    private assertTakeoverWinner;
    private commitInstance;
    private clearState;
    private requireUniqueSurface;
    private currentSessionId;
    private rollbackTakeover;
    private onSurfacesChanged;
}
//# sourceMappingURL=service.d.ts.map