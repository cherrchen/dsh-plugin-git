/**
 * Navigation helpers for push / replace / back / dedupe over one session state.
 */
import type { DetailsSurfaceDescriptor, DetailsSurfaceInstance } from './contract.ts';
import { type DetailsSessionState } from './session-state.ts';
/**
 * Compute a dedupe key for a surface open, when the descriptor defines one.
 * @param descriptor - optional surface descriptor.
 * @param payload - open payload.
 * @returns dedupe key, or undefined when dedupe does not apply.
 */
export declare function resolveDedupeKey(descriptor: DetailsSurfaceDescriptor | undefined, payload: unknown): string | undefined;
/**
 * Find an existing instance matching surface id + dedupe key in active or stack.
 * @param state - session navigation state.
 * @param surfaceId - surface type id.
 * @param key - dedupe key.
 * @returns match location, or undefined.
 */
export declare function findDedupedInstance(state: DetailsSessionState, surfaceId: string, key: string, descriptor: DetailsSurfaceDescriptor): {
    instance: DetailsSurfaceInstance;
    where: 'active' | 'stack';
    index: number;
} | undefined;
/**
 * Push `previous` onto the back stack and trim to {@link DETAILS_HISTORY_LIMIT}.
 * @param state - session state to mutate.
 * @param previous - instance leaving the active seat into history.
 * @returns instances evicted from the oldest end (for lifecycle).
 */
export declare function pushToHistory(state: DetailsSessionState, previous: DetailsSurfaceInstance): DetailsSurfaceInstance[];
/**
 * Pop the most recent history entry, or undefined when empty.
 * @param state - session state to mutate.
 * @returns the restored instance, or undefined.
 */
export declare function popHistory(state: DetailsSessionState): DetailsSurfaceInstance | undefined;
/**
 * Remove every instance of `surfaceId` from active and history.
 * @param state - session state to mutate.
 * @param surfaceId - surface type to purge.
 * @returns removed instances (active first, then stack oldest→newest).
 */
export declare function pruneSurfaceId(state: DetailsSessionState, surfaceId: string): DetailsSurfaceInstance[];
/**
 * Whether the session can navigate back.
 * @param state - session state.
 * @returns true when the back stack is non-empty.
 */
export declare function canGoBack(state: DetailsSessionState): boolean;
/**
 * Replace an instance payload while preserving identity fields.
 * @param instance - existing instance.
 * @param payload - latest open payload.
 * @param label - optional refreshed label.
 * @returns updated instance with the same `instanceId`.
 */
export declare function withUpdatedPayload<P>(instance: DetailsSurfaceInstance<P>, payload: P, label?: string): DetailsSurfaceInstance<P>;
//# sourceMappingURL=navigation.d.ts.map