/**
 * Error boundary around one details surface body: a plugin render error
 * isolates to its tab instead of crashing the dock or the app frame.
 */
import { Component } from 'react';
import type { ErrorInfo, ReactNode } from 'react';
interface SurfaceErrorBoundaryProps {
    /** Rendered surface body. */
    children: ReactNode;
    /** Surface id for the diagnostic message. */
    surfaceId: string;
}
interface SurfaceErrorBoundaryState {
    error: Error | null;
}
/** Catch render errors from one surface contribution. */
export declare class SurfaceErrorBoundary extends Component<SurfaceErrorBoundaryProps, SurfaceErrorBoundaryState> {
    state: SurfaceErrorBoundaryState;
    static getDerivedStateFromError(error: Error): SurfaceErrorBoundaryState;
    componentDidCatch(error: Error, info: ErrorInfo): void;
    componentDidUpdate(prevProps: SurfaceErrorBoundaryProps): void;
    render(): ReactNode;
}
export {};
//# sourceMappingURL=SurfaceErrorBoundary.d.ts.map