/**
 * Per-session details navigation state: the live tab list plus launcher and
 * MRU bookkeeping. Memory only; cleared on Host unload or when a session
 * disappears from the sessions list.
 */
import type { DetailsSurfaceInstance } from './contract.ts';
/** Maximum tabs retained per session; oldest non-active tabs are evicted. */
export declare const DETAILS_TAB_LIMIT = 20;
/**
 * One session's tabbed navigation state.
 * `activeInstanceId` selects among `tabs`; `mru` holds other-tab instance ids
 * most-recent-first (the compatibility face of the v2 back stack);
 * `launcherVisible` shows the Launcher page over the active tab.
 */
export interface DetailsSessionState {
    tabs: DetailsSurfaceInstance[];
    activeInstanceId: string | null;
    launcherVisible: boolean;
    mru: string[];
}
/**
 * Create an empty session navigation record.
 * @returns idle session state.
 */
export declare function emptySessionState(): DetailsSessionState;
/** In-memory map of session id → details navigation state. */
export declare class DetailsSessionStore {
    #private;
    /**
     * Read session state without creating it.
     * @param sessionId - session key.
     * @returns the state, or undefined when never opened.
     */
    get(sessionId: string): DetailsSessionState | undefined;
    /**
     * Read or create session state.
     * @param sessionId - session key.
     * @returns mutable session state.
     */
    getOrCreate(sessionId: string): DetailsSessionState;
    /**
     * Drop one session's retained navigation.
     * @param sessionId - session key to purge.
     */
    delete(sessionId: string): void;
    /** Drop every session's retained navigation. */
    clear(): void;
    /**
     * @returns session ids currently retained in the store.
     */
    keys(): IterableIterator<string>;
}
//# sourceMappingURL=session-state.d.ts.map