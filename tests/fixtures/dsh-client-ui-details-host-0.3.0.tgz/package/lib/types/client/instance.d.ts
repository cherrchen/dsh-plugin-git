/**
 * Surface instance identity helpers. Instances double as tabs; one per
 * dedupe key per surface id.
 */
import type { DetailsSurfaceDescriptor, DetailsSurfaceInstance } from './contract.ts';
/**
 * Allocate a Host-scoped unique instance id.
 * @returns a new opaque instance id string.
 */
export declare function createInstanceId(): string;
/**
 * Build a surface instance for an accepted open request.
 * @param surfaceId - registered `shell.details.surface` contribution id.
 * @param payload - open arguments for this instance.
 * @param label - resolved display label.
 * @param sessionId - current session id at creation time.
 * @param descriptor - surface descriptor supplying tab metadata.
 * @returns a new instance record.
 */
export declare function createSurfaceInstance<P = unknown>(surfaceId: string, payload: P, label: string, sessionId: string, descriptor?: DetailsSurfaceDescriptor<P>): DetailsSurfaceInstance<P>;
/**
 * Reset the instance serial counter. Tests only.
 */
export declare function resetInstanceIdCounterForTests(): void;
//# sourceMappingURL=instance.d.ts.map