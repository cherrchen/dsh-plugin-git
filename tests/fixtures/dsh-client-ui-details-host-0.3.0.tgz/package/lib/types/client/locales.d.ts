/**
 * Locale dictionaries for the Details Toggle header entry.
 * Registered under {@link SHELL_DETAILS_LOCALE_NS} at plugin mount.
 */
export declare const NS: "shell-details-toggle";
/** Dictionary keys of the Details Toggle namespace. */
export type DetailsToggleKey = 'toggle.label' | 'toggle.hide' | 'toggle.show' | 'launcher.title' | 'launcher.hint' | 'launcher.empty' | 'tabs.aria' | 'tab.open' | 'tab.close';
/** English dictionary. */
export declare const en: Record<DetailsToggleKey, string>;
/** Chinese dictionary. */
export declare const zh: Record<DetailsToggleKey, string>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'shell-details-toggle': DetailsToggleKey;
    }
}
//# sourceMappingURL=locales.d.ts.map