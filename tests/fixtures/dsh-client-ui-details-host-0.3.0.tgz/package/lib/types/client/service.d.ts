/**
 * ShellDetailsService (`ctx.shellDetails`): per-session tabbed details
 * navigation, launcher registry, takeover, descriptors, and layout open/close.
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import { type DetailsLauncherContribution, type DetailsSurfaceDescriptor, type DetailsSurfaceInstance, type ShellDetailsController, type ShellDetailsFeature, type ShellDetailsOpenRequest, type ShellDetailsSnapshot } from './contract.ts';
/** `ctx.shellDetails` implementation. */
export declare class ShellDetailsService extends Service implements ShellDetailsController {
    static inject: string[];
    readonly apiVersion: 3;
    readonly features: ReadonlySet<ShellDetailsFeature>;
    private readonly owner;
    private readonly state;
    private readonly descriptors;
    private readonly launchers;
    private readonly sessions;
    private takeover;
    private dockVisible;
    /**
     * @param ctx - owning plugin fiber. Takeover registrations ride this fiber
     * so consumer `open()` calls cannot pin the occupant to another plugin.
     */
    constructor(ctx: Context);
    /**
     * Header chrome: the App-level Details Toggle in the session header
     * utilities cluster (right of the Session Log entry). Visibility state is
     * the measured `dockVisible`; the toggle never destroys retained tabs.
     */
    private registerHeaderToggle;
    /**
     * Toggle dock visibility (header toggle entry point). Opening with no live
     * tabs reveals the Launcher; opening with retained tabs re-reveals them.
     * Closing only hides the column — tabs and launcher state survive.
     */
    toggleDock(): void;
    /**
     * Report measured column visibility from the mounted DetailsHost. The
     * false→true transition on an empty session reveals the Launcher.
     * @param visible - whether the dock column currently has width.
     */
    reportDockVisible(visible: boolean): void;
    private onDockRevealed;
    /**
     * @returns the active tab surface id, or null while no tab is active.
     */
    get activeId(): string | null;
    /**
     * @returns the active surface instance, or null while no tab is active.
     */
    get activeInstance(): DetailsSurfaceInstance | null;
    /**
     * Read the public reactive snapshot.
     * @returns current shell details state.
     */
    getSnapshot(): ShellDetailsSnapshot;
    /**
     * Subscribe to public snapshot changes.
     * @param listener - notified after a distinct snapshot is published.
     * @returns unsubscribe.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Register optional behavior metadata for a surface id.
     * @param descriptor - lifecycle, dedupe, and closability metadata.
     * @returns disposer that removes the descriptor.
     */
    registerSurface<P = unknown>(descriptor: DetailsSurfaceDescriptor<P>): () => void;
    /**
     * Register a Launcher contribution. Duplicate contribution ids throw.
     * @param contribution - launcher card metadata and open intent.
     * @returns disposer that removes the contribution.
     */
    registerLauncher(contribution: DetailsLauncherContribution): () => void;
    /**
     * Occupy `details` with DetailsHost, activate a surface as a tab, and open
     * the column.
     * @param id - registered `shell.details.surface` contribution id.
     */
    open(id: string): void;
    /**
     * Occupy `details` with DetailsHost, resolve `request` to a tab
     * (create-or-reuse), activate it, and open the column.
     * @param request - surface id, optional payload, and legacy navigation mode.
     * @returns the committed active instance.
     */
    open<P = unknown>(request: ShellDetailsOpenRequest<P>): DetailsSurfaceInstance<P>;
    /**
     * Close the active tab of the current session (reason `user`). Closing the
     * last tab reveals the Launcher; the dock stays mounted.
     */
    close(): void;
    /**
     * Close the tab with this instance id (reason `user`).
     * @param instanceId - instance id of the tab to close.
     */
    closeTab(instanceId: string): void;
    /**
     * Activate the tab with this instance id and hide the Launcher.
     * @param instanceId - instance id of the tab to activate.
     */
    activate(instanceId: string): void;
    /** Show the Launcher page and reveal the dock. */
    showLauncher(): void;
    /**
     * Restore the most recently active other tab (MRU compatibility face of
     * tab navigation). No-op when there is nothing to restore.
     */
    back(): void;
    /**
     * Whether the current session has an MRU tab to restore.
     * @returns true when {@link back} would activate a tab.
     */
    canGoBack(): boolean;
    /**
     * Open `id` as a tab when it is not the active tab; close the active tab
     * when it is.
     * @param id - registered `shell.details.surface` contribution id.
     */
    toggle(id: string): void;
    /**
     * Whether any tab is active (or the Launcher shows), or whether `id` is the
     * active tab's surface.
     * @param id - optional surface id to compare.
     * @returns open state for the requested query.
     */
    isOpen(id?: string): boolean;
    private commitActivate;
    private onSessionSwitch;
    private purgeDeletedSessions;
    private recoverAfterSurfaceLoss;
    private disposeAllSessions;
    private onSurfacesChanged;
    private surfacePresent;
    private ensureTakeover;
    private releaseTakeover;
    private registerTakeover;
    private assertTakeoverWinner;
    private publishSession;
    private publishIdle;
    /** Republish the current session state (dock visibility changes). */
    private publishCurrent;
    private requireUniqueSurface;
    private currentSessionId;
    private rollbackTakeover;
}
//# sourceMappingURL=service.d.ts.map