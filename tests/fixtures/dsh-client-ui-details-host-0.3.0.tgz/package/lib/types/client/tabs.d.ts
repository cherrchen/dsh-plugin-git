/**
 * Tab navigation helpers over one session state: dedupe lookup, activation,
 * close with fallback, surface pruning, and the MRU history face.
 */
import type { DetailsSurfaceDescriptor, DetailsSurfaceInstance } from './contract.ts';
import { type DetailsSessionState } from './session-state.ts';
/**
 * Compute a dedupe key for a surface open, when the descriptor defines one.
 * @param descriptor - optional surface descriptor.
 * @param payload - open payload.
 * @returns dedupe key, or undefined when dedupe does not apply.
 */
export declare function resolveDedupeKey(descriptor: DetailsSurfaceDescriptor | undefined, payload: unknown): string | undefined;
/**
 * Find an existing tab matching surface id + dedupe key.
 * @param state - session navigation state.
 * @param surfaceId - surface type id.
 * @param key - dedupe key.
 * @returns the matching tab, or undefined.
 */
export declare function findDedupedTab(state: DetailsSessionState, surfaceId: string, key: string, descriptor: DetailsSurfaceDescriptor): DetailsSurfaceInstance | undefined;
/**
 * Record an activation: point `activeInstanceId` at the tab, remember the
 * previously active tab in the MRU list, and hide the Launcher.
 * @param state - session state to mutate.
 * @param instanceId - instance id of the newly active tab.
 */
export declare function activateTab(state: DetailsSessionState, instanceId: string): void;
/**
 * Drop a tab and select the fallback: the most recent MRU entry still present,
 * else the adjacent tab (next, then previous), else none.
 * @param state - session state to mutate.
 * @param instanceId - instance id of the removed tab.
 * @returns the removed instance, or undefined when the id was unknown.
 */
export declare function removeTab(state: DetailsSessionState, instanceId: string): {
    removed: DetailsSurfaceInstance;
    nextActiveId: string | null;
} | undefined;
/**
 * Evict the oldest non-active tab when the tab list exceeds
 * {@link DETAILS_TAB_LIMIT}.
 * @param state - session state to mutate.
 * @returns the evicted instance, or undefined when within the limit.
 */
export declare function evictOldestTab(state: DetailsSessionState): DetailsSurfaceInstance | undefined;
/**
 * Remove every tab of `surfaceId` (surface unload / crash pruning).
 * @param state - session state to mutate.
 * @param surfaceId - surface type to purge.
 * @returns removed instances (activation order preserved) and the surviving
 * active instance id after fallback selection.
 */
export declare function pruneSurfaceId(state: DetailsSessionState, surfaceId: string): {
    removed: DetailsSurfaceInstance[];
    activeInstanceId: string | null;
};
/**
 * Whether the MRU history can restore a tab.
 * @param state - session state.
 * @returns true when a back activation would land on a live tab.
 */
export declare function canGoBack(state: DetailsSessionState): boolean;
/**
 * Pop the most recent MRU entry that still resolves to a live tab.
 * @param state - session state.
 * @returns the instance id to activate, or undefined.
 */
export declare function popMru(state: DetailsSessionState): string | undefined;
/**
 * Whether an instance id resolves to a live tab.
 * @param state - session state.
 * @param instanceId - instance id to check.
 * @returns true when the tab exists.
 */
export declare function hasTab(state: DetailsSessionState, instanceId: string): boolean;
/**
 * Replace a tab payload while preserving identity fields.
 * @param instance - existing tab.
 * @param payload - latest open payload.
 * @param label - optional refreshed label.
 * @returns updated tab with the same `instanceId`.
 */
export declare function withUpdatedPayload<P>(instance: DetailsSurfaceInstance<P>, payload: P, label?: string): DetailsSurfaceInstance<P>;
//# sourceMappingURL=tabs.d.ts.map