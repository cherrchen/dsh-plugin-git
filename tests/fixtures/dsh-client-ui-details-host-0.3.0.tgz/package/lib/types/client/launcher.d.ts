/**
 * Launcher contribution registry. The Launcher is generated dynamically from
 * live contributions — plugins register on load and dispose on unload; no
 * plugin is hardcoded into the Launcher.
 */
import type { DetailsLauncherContribution } from './contract.ts';
/** Mutable registry of Launcher contributions. */
export declare class DetailsLauncherRegistry {
    #private;
    /**
     * Register one contribution. Duplicate ids throw.
     * @param contribution - launcher card metadata and open intent.
     * @returns disposer that removes the contribution.
     */
    register(contribution: DetailsLauncherContribution): () => void;
    /**
     * Visible contributions, sorted by ascending `order` (ties keep
     * registration order), with `when()` predicates applied.
     * @returns the rendered card list.
     */
    list(): DetailsLauncherContribution[];
    /** Remove every contribution (host unload). */
    clear(): void;
}
//# sourceMappingURL=launcher.d.ts.map