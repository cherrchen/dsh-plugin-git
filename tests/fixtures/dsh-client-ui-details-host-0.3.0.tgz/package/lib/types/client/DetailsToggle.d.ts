/**
 * App-level Details Toggle in the session header utilities cluster. Shows or
 * hides the details dock; hiding never destroys retained tabs. Pressed state
 * mirrors the measured dock visibility, not the tab list.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { CONVERSATION_HEADER_UTILITIES_SLOT, SHELL_DETAILS_LOCALE_NS, type DetailsToggleInjected } from './contract.ts';
/** Full composed props for the header toggle registration. */
export type DetailsToggleProps = PropsRuntime<typeof CONVERSATION_HEADER_UTILITIES_SLOT> & PropsLocale<typeof SHELL_DETAILS_LOCALE_NS> & InjectFace<DetailsToggleInjected>;
/**
 * Render the header Details Toggle.
 * @param props - header runtime, locale copy, and injected toggle face.
 * @returns the toggle button.
 */
export declare function DetailsToggle({ useDetailsToggle, toggleDock, t }: DetailsToggleProps): import("react").JSX.Element;
//# sourceMappingURL=DetailsToggle.d.ts.map