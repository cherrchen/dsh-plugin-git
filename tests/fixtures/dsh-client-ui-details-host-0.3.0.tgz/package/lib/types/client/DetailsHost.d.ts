import type { InjectFace, PropsLocale, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { SHELL_DETAILS_LOCALE_NS, type DetailsHostInjected } from './contract.ts';
/** Full composed props for the DetailsHost `details` registration. */
export type DetailsHostProps = PropsRuntime<'details'> & PropsLocale<typeof SHELL_DETAILS_LOCALE_NS> & PropsRenderSlots<'shell.details.surface' | 'shell.details.header.actions'> & InjectFace<DetailsHostInjected>;
/**
 * Render the hosted details column: tab bar, launcher, and active surface.
 * @param props - slot runtime, child render, and injected controller face.
 * @returns the hosted column.
 */
export declare function DetailsHost({ renderSlot, useDetailsHost, launcherEntries, reportDockVisible, activate, closeTab, showLauncher, openRequest, t, }: DetailsHostProps): import("react").JSX.Element;
//# sourceMappingURL=DetailsHost.d.ts.map