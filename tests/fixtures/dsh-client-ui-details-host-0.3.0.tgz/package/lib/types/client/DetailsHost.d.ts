import type { InjectFace, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type DetailsHostInjected } from './contract.ts';
/** Full composed props for the DetailsHost `details` registration. */
export type DetailsHostProps = PropsRuntime<'details'> & PropsRenderSlots<'shell.details.surface' | 'shell.details.header.actions'> & InjectFace<DetailsHostInjected>;
/**
 * Render the hosted details column: tab bar, launcher, and active surface.
 * @param props - slot runtime, child render, and injected controller face.
 * @returns the hosted column.
 */
export declare function DetailsHost({ renderSlot, useDetailsHost, launcherEntries, reportDockVisible, activate, closeTab, showLauncher, openRequest, }: DetailsHostProps): import("react").JSX.Element;
//# sourceMappingURL=DetailsHost.d.ts.map