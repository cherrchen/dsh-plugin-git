/**
 * Details column occupant: header chrome plus the active `shell.details.surface`
 * contribution. Panel width stays with `ctx.layout`.
 */
import type { InjectFace, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type DetailsHostInjected } from './contract.ts';
/** Full composed props for the DetailsHost `details` registration. */
export type DetailsHostProps = PropsRuntime<'details'> & PropsRenderSlots<'shell.details.surface'> & InjectFace<DetailsHostInjected>;
/**
 * Render the hosted details column for the active surface.
 * @param props - slot runtime, child render, and injected controller face.
 * @returns the hosted column, or null while no surface is active.
 */
export declare function DetailsHost({ renderSlot, useDetailsHost, close }: DetailsHostProps): import("react").JSX.Element | null;
//# sourceMappingURL=DetailsHost.d.ts.map