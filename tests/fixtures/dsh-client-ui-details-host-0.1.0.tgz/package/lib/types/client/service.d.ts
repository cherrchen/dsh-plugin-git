/**
 * ShellDetailsService (`ctx.shellDetails`): dynamic `details` takeover,
 * one active `shell.details.surface` id, and layout open/close delegation.
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import { type ShellDetailsController } from './contract.ts';
/** `ctx.shellDetails` implementation. */
export declare class ShellDetailsService extends Service implements ShellDetailsController {
    static inject: string[];
    private readonly owner;
    private readonly state;
    private takeover;
    /**
     * @param ctx - owning plugin fiber. Takeover registrations ride this fiber
     * so consumer `open()` calls cannot pin the occupant to another plugin.
     */
    constructor(ctx: Context);
    /**
     * @returns the active surface id, or null while closed.
     */
    get activeId(): string | null;
    /**
     * Occupy `details` with DetailsHost, activate `id`, and open the column.
     * @param id - registered `shell.details.surface` contribution id.
     */
    open(id: string): void;
    /**
     * Close the details column, clear the active id, and dispose takeover.
     */
    close(): void;
    /**
     * Open `id` when it is not active; close when it is.
     * @param id - registered `shell.details.surface` contribution id.
     */
    toggle(id: string): void;
    /**
     * Whether any surface is active, or whether `id` is the active surface.
     * @param id - optional surface id to compare.
     * @returns open state for the requested query.
     */
    isOpen(id?: string): boolean;
    private activate;
    private requireSurface;
    private rollbackTakeover;
    private onSurfacesChanged;
}
//# sourceMappingURL=service.d.ts.map